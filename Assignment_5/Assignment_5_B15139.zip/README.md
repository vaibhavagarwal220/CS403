## Assignment 5
### CS403- Algorithms Design and Analysis

1. To test a code for a file, first compile the respective file by using the command:
	
	``g++ -o Q<n> Q<n>.cpp``

2. To run a particular executable for a question whose code is compiled enter the command:
	``./Q<n> < input/input_Q<n>.txt``

(Where n is the number of the question whose code you want to compile/run)
	

#### Report.pdf contains the details on runtime complexity and explanation of problem and their algorithm.
